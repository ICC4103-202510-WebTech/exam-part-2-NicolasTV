# This file should ensure the existence of records required to run the application in every environment (production,
# development, test). The code here should be idempotent so that it can be executed at any point in every environment.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Example:
#
#   ["Action", "Comedy", "Drama", "Horror"].each do |genre_name|
#     MovieGenre.find_or_create_by!(name: genre_name)
#   end

Advice.create([
    {content: "Good day!", author:"Nick"},
    {content: "Stay positive", author:"Juanito"},
    {content: "Keep going", author: "Vale"},
    {content: "Well done", author:"Tom"},
    {content: "Trust the procces", author:"Ruby"},
    {content: "Nice work", author: "Rai"},
    {content: "Have a nice day", author: "Carola"},
    {content: "Believe you can and you're halfway there", author:"Javier"},
    {content: "The only way to do great work is to love what you do", author:"Joaquin"},
    {content: "Don't watch the clock; do what it does. Keep going" }

])