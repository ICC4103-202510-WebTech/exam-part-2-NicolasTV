module AdvicesHelper
end
