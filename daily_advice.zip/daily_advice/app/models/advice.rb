class Advice < ApplicationRecord
    validates :content, presence: true
  end
  
