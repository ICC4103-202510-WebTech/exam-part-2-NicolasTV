class AdvicesController < ApplicationController
  before_action :authenticate_user!, only: [:new, :create, :edit, :update]
  before_action :set_advice, only: [:show, :edit, :update]

  def random
    @advice = Advice.order("RANDOM()").first
  end

  def index
    @advices = Advice.all
  end

  def show
  end

  def new
    @advice = Advice.new
  end

  def create
    @advice = Advice.new(advice_params)
    if @advice.save
      redirect_to @advice, notice: "Advice created successfully."
    else
      render :new
    end
  end

  def edit
  end

  def update
    if @advice.update(advice_params)
      redirect_to @advice, notice: "Advice updated successfully."
    else
      render :edit
    end
  end

  private

  def set_advice
    @advice = Advice.find(params[:id])
  end

  def advice_params
    params.require(:advice).permit(:content, :author)
  end
end

