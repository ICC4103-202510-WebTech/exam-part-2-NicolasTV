require "test_helper"

class AdviceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
